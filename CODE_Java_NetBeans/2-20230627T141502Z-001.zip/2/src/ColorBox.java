/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author bravee06
 */
// Box : super class 
public class ColorBox extends Box {
    private int color;

    public ColorBox() {
    }

    public ColorBox( String code, double price,int color) {
        super(code, price);
        this.color = color;
    }
    
    public double getNewPrice(){
       
        // return the value price = price + inc 
        // if color > 100 : inc = 10 else inc = 0
        if(this.color > 100) return super.getPrice()*1.1;
        return super.getPrice();
    }

    @Override
    public String toString() {
        return super.toString() + "\t" + this.color;
    }
    
    
    
    
}
