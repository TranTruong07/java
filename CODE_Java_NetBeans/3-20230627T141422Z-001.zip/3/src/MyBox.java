
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author bravee06
 */
public class MyBox implements IBox {

    @Override
    public void f1(List<Box> list) {
        for (Box b : list) {
//  Cach 1       String firstChar = Character.toString(b.getCode().charAt(0);
            String firstChar = "" + b.getCode().charAt(0);
            if(firstChar.equals("K")){
                b.setPrice(1.1*b.getPrice());
            }

        }
    }

    @Override
    public int f2(List<Box> list, double d) {
        int count = 0;
        for (Box b : list) {
            double price = b.getPrice();
            if(price > d){
                count++;
            }
        }
        return count;
    }

    @Override
    public void f3(List<Box> list) {
        int minPriceIndex = 0;
        
        Box bMin  = new Box();
        for(int i = 0; i < list.size(); i++){
            double price = list.get(i).getPrice();
            double minPrice = list.get(minPriceIndex).getPrice();
            if(price < minPrice){
                    minPriceIndex = i;
            }
        }
        if(minPriceIndex != list.size() -1){
            list.remove(minPriceIndex+1);
        }
            
        
    }

}
